@echo off
cd /d %~dp0
if not exist .env copy .env.example .env >nul
where node >nul 2>nul || (echo Node.js 20+ is required & pause & exit /b 1)
echo Starting SINERGY GROWTH OS at http://127.0.0.1:8787
start "" http://127.0.0.1:8787
node server.js
pause
