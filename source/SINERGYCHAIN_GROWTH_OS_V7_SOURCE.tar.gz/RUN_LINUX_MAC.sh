#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
[ -f .env ] || cp .env.example .env
echo "Starting SINERGY GROWTH OS at http://127.0.0.1:8787"
exec node server.js
